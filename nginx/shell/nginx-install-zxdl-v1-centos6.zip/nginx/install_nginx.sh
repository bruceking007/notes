#!/bin/bash
#Detects whether the user has root privileges
Detect> $0.log 2>&1
if [ $UID -ne 0 ]; then
    echo "Superuser privileges are required to run this script."
    exit 1
fi

####nginx###
echo "5秒后执行本脚本，本次PID = $$ 。"
sleep 5
DownDir=/usr/local/src/nginx    #Download the file save directory
SoftDir=/usr/local	#Software installation directory
#Url="http://tar.realbwt.com/nginx"
PWD=`pwd`
#清空 DownDir下的文件夹

#Detects whether the user has root privileges
if [ $UID -ne 0 ]; then
    echo "Superuser privileges are required to run this script."
    exit 1
fi
if [ $PWD != '/usr/local/src/nginx' ]; then
    echo "please move file to /usr/local/src/nginx"
    exit 1
fi

function check_ok(){	##Check it Fail or Success 自检函数
	[ $? -ne 0 ] && exit 1 && echo "$1 is Fail!" || echo "$1 is Success!"
}
function check_user(){	##Check User 确认用户存在函数
	grep "$1" /etc/group
	[ $? != 0 ] && groupadd $1
	grep "$1" /etc/passwd
	[ $? != 0 ] && useradd -s /sbin/nologin -g $1 $1
}
function UnZip(){	##解压函数
	TarName=$1
	TarType=${TarName##*.}
	#if [ ! -f $DownDir/$TarName ] ;then
		#wget -P $DownDir $Url/$TarName
	#fi
	if [ "$TarType" == "zip" ] ;then
		cd $DownDir && unzip -o $TarName
		check_ok
	else
		tar xf $DownDir/$TarName -C $DownDir/
		check_ok
	fi
	ser=`echo $TarName | sed -e 's#^\(.*\)-[0-9]*.*#\1#g'`       #service name
	dir=`ls $DownDir | grep $ser |grep -v tar.gz`   #unzip dir
	if [ -z $dir ] ;then
		ser=`echo $TarName | awk -F "[._-]" '{print $1}'`
		dir=`ls $DownDir | grep $ser | grep -v tar.gz`
	fi
	echo "-----------\n TarName=$TarName |ServiceName=$ser |UnzipDir=$dir \n-----------"
}
function Install(){	##安装函数,依赖解压函数
	cd $DownDir/$dir
	./configure $1
	check_ok $ser
	make && make install
	check_ok $ser
	cd $DownDir
	rm -rf $dir
	}
yum install -y gcc-c++ gcc zlib-devel libxslt-devel gd-devel patch unzip perl-devel libtool

##INSTALL libunwind
UnZip "libunwind-1.1.tar.gz" && Install
##INSTALL GperfTools
UnZip "gperftools-2.1.tar.gz" && Install
##INSTALL LuaJIT
UnZip "LuaJIT-2.0.3.tar.gz"
cd $DownDir/$dir
make
check_ok $ser
make install
check_ok $ser
##INSTALL LibMaxminddb
UnZip "libmaxminddb-0.5.5.tar.gz" && Install
##INSTALL Geoip
UnZip "GeoIP.tar.gz" && Install
##Unzip openssl,pcre,ngx_cache_purge,nginx_hmux_module,nginx_tcp_proxy_module.zip,ngx_http_geoip2_module-master.zip
array=(openssl-1.0.2.tar.gz pcre-8.36.tar.gz ngx_cache_purge-2.3.tar.gz nginx_hmux_module.tar.gz nginx_tcp_proxy_module.zip ngx_http_geoip2_module-master.zip )
for i in ${array[@]};do UnZip $i ;done
#各个库的软链接：
ln -svf /usr/local/lib/libmaxminddb.so.0 /usr/lib64/libmaxminddb.so.0
ln -svf /usr/local/lib/libunwind.so.8 /usr/lib64/libunwind.so.8
ln -svf /usr/local/lib/libluajit-5.1.so.2 /usr/lib64/libluajit-5.1.so.2
ln -svf /usr/local/lib/libtcmalloc_minimal.so.4 /usr/lib64/libtcmalloc_minimal.so.4
ln -svf /usr/local/lib/libprofiler.so.0 /usr/lib64/libprofiler.so.0

##INSTALL TENGINE
UnZip "tengine-2.1.0.tar.gz"
cd $DownDir/$dir
patch -p1 < $DownDir/ngx_http_proxy_connect_module/patch/proxy_connect.patch
./configure --prefix=/usr/local/nginx \
--pid-path=/var/run/nginx.pid \
--error-log-path=/data/nginx/logs/error.log \
--http-log-path=/data/nginx/logs/access.log \
--with-pcre=$DownDir/pcre-8.36 \
--with-openssl=$DownDir/openssl-1.0.2 \
--with-openssl-opt=-fPIC \
--with-http_lua_module \
--with-luajit-inc=/usr/local/include/luajit-2.0 \
--with-luajit-lib=/usr/local/lib \
--with-backtrace_module \
--with-http_stub_status_module \
--with-http_gzip_static_module \
--with-http_realip_module \
--with-http_upstream_check_module \
--with-http_ssl_module \
--with-http_sub_module \
--with-md5=/usr/lib \
--with-http_concat_module=shared \
--with-http_sysguard_module=shared \
--with-http_limit_conn_module=shared \
--with-http_limit_req_module=shared \
--with-http_split_clients_module=shared \
--with-http_footer_filter_module=shared \
--with-http_sub_module=shared \
--with-http_access_module=shared \
--with-http_upstream_ip_hash_module=shared \
--with-http_upstream_least_conn_module=shared \
--with-http_addition_module=shared \
--with-http_referer_module=shared \
--with-http_rewrite_module=shared \
--with-http_memcached_module=shared \
--with-http_upstream_session_sticky_module=shared \
--with-http_addition_module=shared \
--with-http_xslt_module=shared \
--with-http_image_filter_module=shared \
--with-http_user_agent_module=shared \
--with-http_empty_gif_module=shared \
--with-http_browser_module=shared \
--with-google_perftools_module \
--with-http_map_module=shared \
--with-http_split_clients_module=shared \
--with-http_userid_filter_module=shared \
--with-http_charset_filter_module=shared \
--without-http_uwsgi_module \
--without-http_scgi_module \
--without-select_module \
--without-poll_module \
--add-module=$DownDir/nginx-hmux-module-1.3 \
--add-module=$DownDir/ngx_cache_purge-2.3 \
--add-module=$DownDir/nginx_tcp_proxy_module-master \
--add-module=$DownDir/ngx_http_geoip2_module-master \
--add-module=$DownDir/ngx_http_proxy_connect_module \
--with-ld-opt=-ltcmalloc_minimal \
--http-client-body-temp-path=/data/nginx/tmps/nginx_client \
--http-proxy-temp-path=/data/nginx/tmps/nginx_proxy \
--http-fastcgi-temp-path=/data/nginx/tmps/nginx_fastcgi
check_ok $ser
##INSTALL patch
patch -p1 < $DownDir/nginx_tcp_proxy_module-master/tcp.patch
check_ok $ser
make && make install
check_ok $ser
check_user nginx
mkdir -p /data/nginx/tmps
chown -R nginx /data/nginx

#解压conf配置模板
cd $DownDir && rm -rf /usr/local/nginx/conf && tar xf conf.tar.gz -C /usr/local/nginx/

#创建相应nginxLog目录
#mkdir /data/nginx/logs/{boss,gateway,merchant,rpms,hack}

#wget -P $SoftDir/nginx/conf/ $Url/GeoLite2-Country.mmdb 
check_ok
#测试配置是否问题
/usr/local/nginx/sbin/nginx -t
check_ok "new nginx_conf test start"
cat > /usr/local/nginx/html/robots.txt <<EOF
User-agent: Baiduspider
Disallow: /agent*

User-agent: Googlebot
Disallow: /agent*

User-agent: *
Disallow: /
EOF

#创建启动脚本并注册服务
cat <<EOF > /etc/init.d/nginx
#!/bin/bash
# chkconfig: - 30 21
# description: http service.
# Source Function Library
. /etc/init.d/functions
# Nginx Settings

NGINX_SBIN="/usr/local/nginx/sbin/nginx"
NGINX_CONF="/usr/local/nginx/conf/nginx.conf"
NGINX_PID="/var/run/nginx.pid"
RETVAL=0
prog="Nginx"

start() {
        echo -n \$"Starting \$prog: "
        mkdir -p /dev/shm/nginx_temp
        daemon \$NGINX_SBIN -c \$NGINX_CONF
        RETVAL=\$?
        echo
        return \$RETVAL
}

stop() {
        echo -n \$"Stopping \$prog: "
        killproc -p \$NGINX_PID \$NGINX_SBIN -TERM
        rm -rf /dev/shm/nginx_temp
        RETVAL=\$?
        echo
        return \$RETVAL
}

reload(){
        echo -n \$"Reloading \$prog: "
        killproc -p \$NGINX_PID \$NGINX_SBIN -HUP
        RETVAL=\$?
        echo
        return \$RETVAL
}

restart(){
        stop
        start
}

configtest(){
    \$NGINX_SBIN -c \$NGINX_CONF -t
    return 0
}

case "\$1" in
  start)
        start
        ;;
  stop)
        stop
        ;;
  reload)
        reload
        ;;
  restart)
        restart
        ;;
  configtest)
        configtest
        ;;
  *)
        echo $"Usage: \$0 {start|stop|reload|restart|configtest}"
        RETVAL=1
esac

exit \$RETVAL
EOF
chmod 755 /etc/init.d/nginx
chkconfig --add nginx
chkconfig nginx on
service nginx start
i=`ps -C nginx --no-heading |wc -l`
if [ "$i" == "0" ];then
	echo "Nginx start faild" && service nginx restart
fi
#开启防火墙的80端口：
iptables -I INPUT -p tcp --dport 80 -j ACCEPT && service iptables save
#按天切割nginx 日志：
cat <<EOF > /opt/scripts/nginx_log.sh
#!/bin/sh
#author: jay
#date: 2019-07-01
#desc: For cut nginx log
#定义nginx 日志路径
Logpath="/data/nginx/logs/"
Logpath1="/data/nginx/logs/proxy/"
#删除/data目录下的lost+found目录
rm -rf /data/lost+found
#定义nginx 访问日志文件名称
log_name="access.log"
#重命名nginx 文件
mv $Logpath${log_name} $Logpath/access-`date -d last-day +%F`.log
mv $Logpath1${log_name} $Logpath1/access-`date -d last-day +%F`.log
#重载nginx 服务
/usr/local/nginx/sbin/nginx -s reload
#查找nginx 日志目录下30天前的日志并删除
find  /data/nginx/logs/ -name '*.log' -mtime +30 -exec rm -rf {} \;
EOF
#建立计划任务，每天0点0分执行nginx 日志切割
echo "0 0 * * * root /bin/bash /opt/scripts/nginx_log.sh" >> /etc/crontab
check_ok "nginx_log crontab"

sed -i 's/^HOSTNAME=.*$/HOSTNAME='$name'/g' /etc/sysconfig/network
#hostmonitor_configure
/etc/init.d/nginx reload
ps -ef|grep --color=auto nginx

#软链接
ln -sfv /usr/local/nginx/sbin/nginx /usr/bin/nginx

#NGINX语法高亮
mkdir -p ~/.vim/syntax && cd ~/.vim/syntax
wget http://www.vim.org/scripts/download_script.php?src_id=14376 -O nginx.vim >/dev/null
echo "au BufRead,BufNewFile /usr/local/nginx/conf/* set ft=nginx" > ~/.vim/filetype.vim

