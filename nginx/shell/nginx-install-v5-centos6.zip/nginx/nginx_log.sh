#!/bin/sh
#author: jay
#date: 2019-07-01
#desc: For cut nginx log
#定义nginx 日志路径
Logpath="/data/nginx/logs/"
Logpath1="/data/nginx/logs/boss/"
Logpath2="/data/nginx/logs/gateway/"
Logpath3="/data/nginx/logs/merchant/"
Logpath4="/data/nginx/logs/rpms/"
#删除/data目录下的lost+found目录
rm -rf /data/lost+found
#定义nginx 访问日志文件名称
log_name="access.log"
log_monit="monitor.log"
#重命名nginx 文件
mv $Logpath${log_name} $Logpath/access-`date -d last-day +%F`.log
mv $Logpath1${log_name} $Logpath1/access-`date -d last-day +%F`.log
mv $Logpath2${log_name} $Logpath2/access-`date -d last-day +%F`.log
mv $Logpath3${log_name} $Logpath3/access-`date -d last-day +%F`.log
mv $Logpath4${log_name} $Logpath4/access-`date -d last-day +%F`.log
mv $Logpath2${log_monit} $Logpath2/monitor-`date -d last-day +%F`.log
#重载nginx 服务
/usr/local/nginx/sbin/nginx -s reload
#查找nginx 日志目录下30天前的日志并删除
find  /data/nginx/logs/ -name '*.log' -mtime +30 -exec rm -rf {} \;