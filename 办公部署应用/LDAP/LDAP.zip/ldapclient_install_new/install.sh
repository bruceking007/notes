#!/bin/bash
#2016-9-1 author shean
#2019-05-13 modify cody
#ldap client installing 
#export PROMPT_COMMAND='{ msg=$(history 1 | { read x y; echo $y; });logger "[euid=$(whoami)]":$(who am i):[`pwd`]"$msg"; }' command saveing syslog
#**** allow one times this script of the computer, disable running second times ****

Environment_ID=$1

if [ $UID -ne 0 ]; then
    echo "Superuser privileges are required to run this script!!!"
    exit 1
fi

function Choose_Environment(){
    if [ -z $Environment_ID ]
    then
        echo "执行脚本时选择环境ID"
        echo "+----+--------------------------------------------+"
        echo "|ID  |Environment                                 |"
        echo "+----+--------------------------------------------+"
        echo "|1   | Default                                    |"
        echo "|2   | OP-DEV                                     |"
        echo "|3   | OP-SIT                                     |"
        echo "|4   | OP-UAT                                     |"
        echo "|5   | OP-PUAT                                    |"
        echo "|6   | OP-UATB                                    |"
        echo "|7   | OP-Core                                    |"
        echo "|8   | OP-Core-DB                                 |"
        echo "|9   | OG-Core                                    |"
        echo "|10  | OG-Core-DB                                 |"
        echo "|11  | OT-Core                                    |"
        echo "|12  | OT-Core-DB                                 |"
        echo "|13  | 内网机器                                   |"
        echo "+----+--------------------------------------------+"
        exit 2
    elif [ $Environment_ID -gt 0 ];then
        echo "LDAP client start installation..."
    fi
}

function Config_LDAP(){
    system_version=`uname -r | awk -F '.' '{print $1}'`
    hostname=$(hostname)
    if [ -f /etc/openldap/cacerts/ldap1.pem ];then
        mv /etc/openldap/cacerts/ /etc/openldap/cacerts_old
        mkdir /etc/openldap/cacerts
    fi
    setenforce 0
    sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/selinux/config
    echo "59.152.212.20 server1.cattlee.com" >> /etc/hosts
    echo "202.155.226.80 server2.cattlee.com">> /etc/hosts
    echo "127.0.0.1 ${hostname}" >> /etc/hosts
    yum  install nss-pam-ldapd oddjob-mkhomedir dbus sssd openldap-clients openssh-ldap -y
    chkconfig messagebus on || systemctl enable messagebus
    chkconfig nslcd on || systemctl enable nslcd
    chkconfig sssd on || systemctl enable sssd
    service messagebus restart || systemctl restart messagebus
    authconfig --enableldap --enableldapauth --ldapserver=ldaps://server1.cattlee.com,ldaps://server2.cattlee.com --ldapbasedn=dc=cattlee,dc=com --enableldaptls --enableldapstarttls --enablesssd --enablesssdauth --enablemkhomedir --updateall
    cp -a /etc/sudo-ldap.conf /etc/sudo-ldap.conf_bak
    echo "session    required     pam_mkhomedir.so skel=/etc/skel/ umask=0022" >> /etc/pam.d/sshd
    mkdir -p /etc/openldap/cacerts
    cp -r cacert0{1,2}.pem /etc/openldap/cacerts
    cp -r ldap.conf /etc/openldap/ldap.conf
    cp -r ldap.conf /etc/ssh/ldap.conf
    cp -r pam_ldap.conf /etc/pam_ldap.conf
    cp -r authconfig /etc/sysconfig/authconfig
    cp -r nslcd.conf /etc/nslcd.conf
    cp -r nsswitch.conf /etc/nsswitch.conf
    cp -r sudo-ldap.conf /etc/sudo-ldap.conf
    chmod 600 /etc/sssd/sssd.conf
    service nslcd restart || systemctl restart nslcd
    authconfig --enableldap --enableldapauth --update
    sss_cache -E
    if [ $system_version = 3 ];then
        systemctl restart systemd-logind
    fi
}


function Config_SSH(){
    sed -i '/^#PubkeyAuthentication yes/a\PubkeyAuthentication yes' /etc/ssh/sshd_config
    sed -i '/^#AuthorizedKeysCommand none$/a\AuthorizedKeysCommand /usr/libexec/openssh/ssh-ldap-wrapper' /etc/ssh/sshd_config
    sed -i '/^#AuthorizedKeysCommandRunAs nobody$/a\AuthorizedKeysCommandRunAs nobody' /etc/ssh/sshd_config
    sed -i '/^#AuthorizedKeysCommandUser nobody$/a\AuthorizedKeysCommandUser nobody' /etc/ssh/sshd_config
    sed -i '/^ClientAliveCountMax.*/d' /etc/ssh/sshd_config
    echo "ClientAliveCountMax 5" >> /etc/ssh/sshd_config
    service sshd restart || systemctl restart sshd
}

Choose_Environment
Config_LDAP
Config_SSH

case $Environment_ID in
        1)
            sed -i "s/ou=SUDOers,dc=cattlee,dc=com/ou=OP-Default,ou=SUDOers,dc=cattlee,dc=com/g" /etc/sudo-ldap.conf
            cp -r sssd/sssd-default.conf /etc/sssd/sssd.conf
            service sssd restart || systemctl restart sssd
            ;;
        2)
            sed -i "s/ou=SUDOers,dc=cattlee,dc=com/ou=OP-DEV,ou=SUDOers,dc=cattlee,dc=com/g" /etc/sudo-ldap.conf
            cp -r sssd/sssd-test.conf /etc/sssd/sssd.conf
            service sssd restart || systemctl restart sssd
			;;
        3)
            sed -i "s/ou=SUDOers,dc=cattlee,dc=com/ou=OP-SIT,ou=SUDOers,dc=cattlee,dc=com/g" /etc/sudo-ldap.conf
            cp -r sssd/sssd-test.conf /etc/sssd/sssd.conf
            service sssd restart || systemctl restart sssd
            ;;  
        4)      
            sed -i "s/ou=SUDOers,dc=cattlee,dc=com/ou=OP-UAT,ou=SUDOers,dc=cattlee,dc=com/g" /etc/sudo-ldap.conf
            cp -r sssd/sssd-test.conf /etc/sssd/sssd.conf
            service sssd restart || systemctl restart sssd
            ;;
        5)   
            sed -i "s/ou=SUDOers,dc=cattlee,dc=com/ou=OP-PUAT,ou=SUDOers,dc=cattlee,dc=com/g" /etc/sudo-ldap.conf
            cp -r sssd/sssd-test.conf /etc/sssd/sssd.conf
            service sssd restart || systemctl restart sssd
            ;;  
        6)
            sed -i "s/ou=SUDOers,dc=cattlee,dc=com/ou=OP-UATB,ou=SUDOers,dc=cattlee,dc=com/g" /etc/sudo-ldap.conf
            cp -r sssd/sssd-test.conf /etc/sssd/sssd.conf
            service sssd restart || systemctl restart sssd
            ;;
        7)
            sed -i "s/ou=SUDOers,dc=cattlee,dc=com/ou=OP-Core,ou=SUDOers,dc=cattlee,dc=com/g" /etc/sudo-ldap.conf
            cp -r sssd/sssd-core.conf /etc/sssd/sssd.conf
            service sssd restart || systemctl restart sssd
            sed -i "s/59.152.212.20/10.32.100.211/g" /etc/hosts
            sed -i "s/202.155.226.80/10.34.100.211/g" /etc/hosts
            ;;  
        8)
            sed -i "s/ou=SUDOers,dc=cattlee,dc=com/ou=OP-DB,ou=SUDOers,dc=cattlee,dc=com/g" /etc/sudo-ldap.conf
            cp -r sssd/sssd-db.conf /etc/sssd/sssd.conf
            service sssd restart || systemctl restart sssd
            sed -i "s/59.152.212.20/10.32.100.211/g" /etc/hosts
            sed -i "s/202.155.226.80/10.34.100.211/g" /etc/hosts
            ;;
        9)
            sed -i "s/ou=SUDOers,dc=cattlee,dc=com/ou=OG-Core,ou=SUDOers,dc=cattlee,dc=com/g" /etc/sudo-ldap.conf
            cp -r sssd/sssd-core.conf /etc/sssd/sssd.conf
            service sssd restart || systemctl restart sssd
            sed -i "s/59.152.212.20/10.32.100.211/g" /etc/hosts
            sed -i "s/202.155.226.80/10.34.100.211/g" /etc/hosts
            ;;
        10)
            sed -i "s/ou=SUDOers,dc=cattlee,dc=com/ou=OG-DB,ou=SUDOers,dc=cattlee,dc=com/g" /etc/sudo-ldap.conf
            cp -r sssd/sssd-db.conf /etc/sssd/sssd.conf
            service sssd restart || systemctl restart sssd
            sed -i "s/59.152.212.20/10.32.100.211/g" /etc/hosts
            sed -i "s/202.155.226.80/10.34.100.211/g" /etc/hosts
            ;;
        11)
            sed -i "s/ou=SUDOers,dc=cattlee,dc=com/ou=OP-Core,ou=SUDOers,dc=cattlee,dc=com/g" /etc/sudo-ldap.conf
            cp -r sssd/sssd-core.conf /etc/sssd/sssd.conf
            service sssd restart || systemctl restart sssd
            ;;
        12)
            sed -i "s/ou=SUDOers,dc=cattlee,dc=com/ou=OP-DB,ou=SUDOers,dc=cattlee,dc=com/g" /etc/sudo-ldap.conf
            cp -r sssd/sssd-db.conf /etc/sssd/sssd.conf
            service sssd restart || systemctl restart sssd
            ;;
        13)
            sed -i "s/ou=SUDOers,dc=cattlee,dc=com/ou=OP-Default,ou=SUDOers,dc=cattlee,dc=com/g" /etc/sudo-ldap.conf
            cp -r sssd/sssd-default.conf /etc/sssd/sssd.conf
            service sssd restart || systemctl restart sssd
            sed -i "s/59.152.212.20/10.32.100.211/g" /etc/hosts
            sed -i "s/202.155.226.80/10.34.100.211/g" /etc/hosts
            ;;
    *)
        echo -e "\033[31m 环境ID错误 \033[0m"
esac
