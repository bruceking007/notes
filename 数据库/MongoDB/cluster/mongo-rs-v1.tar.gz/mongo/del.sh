rm -rf ./data
rm -rf ./log
