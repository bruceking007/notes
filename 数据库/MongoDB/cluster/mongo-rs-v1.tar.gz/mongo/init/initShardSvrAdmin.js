use admin;
db.createUser({user: "admin",pwd: "Passwordshrs1",roles: [ { role: "root", db: "admin" } ]});
