use admin;

conf = {
    _id: "shrs01",
    members: [
        { _id: 0, host: "127.0.0.1:10118", priority: 1 },
        { _id: 1, host: "127.0.0.1:10218", priority: 0.5 },
        { _id: 2, host: "127.0.0.1:10318", arbiterOnly:true }
    ]
};

rs.initiate(conf);
