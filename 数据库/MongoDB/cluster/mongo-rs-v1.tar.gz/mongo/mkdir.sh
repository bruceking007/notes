mkdir -pv ./data/configsvr{1,2,3}
mkdir -pv ./log/configsvr{1,2,3}
mkdir -pv ./conf/configsvr{1,2,3}

mkdir -pv ./data/shard{1,1-2,1-3}
mkdir -pv ./data/shard{2,2-2,2-3}
mkdir -pv ./data/shard{3,3-2,3-3}

mkdir -pv ./log/shard{1,1-2,1-3}
mkdir -pv ./log/shard{2,2-2,2-3}
mkdir -pv ./log/shard{3,3-2,3-3}

#mkdir -pv ./conf/shard{1,1-2,1-3}
#mkdir -pv ./conf/shard{2,2-2,2-3}
#mkdir -pv ./conf/shard{3,3-2,3-3}
mkdir -pv ./conf/mongos
mkdir -pv ./log/mongos
chmod -R a+rwx log


