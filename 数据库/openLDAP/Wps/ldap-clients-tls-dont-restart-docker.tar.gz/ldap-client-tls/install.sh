#!/bin/bash
set -x
hostname=$(hostname)

yum  install nss-pam-ldapd oddjob-mkhomedir dbus sssd openldap-clients openssh-ldap -y

chkconfig nslcd on 
chkconfig sssd on 

del () {
    sed -i '/ldap.sun.com/d' /etc/hosts
    sed -i '/pam_mkhomedir.so skel/d' /etc/pam.d/sshd
    sed -i '/^PubkeyAuthentication yes/d' /etc/ssh/sshd_config
    sed -i '/^AuthorizedKeysCommand/d' /etc/ssh/sshd_config
    sed -i '/^AuthorizedKeysCommandRunAs nobody/d' /etc/ssh/sshd_config
    sed -i '/^AuthorizedKeysCommandUser nobody/d' /etc/ssh/sshd_config
}

del
echo "192.168.91.11 ldap.sun.com" >> /etc/hosts

authconfig --enableldap --enableldapauth --ldapserver=ldaps://ldap.sun.com --ldapbasedn=dc=sun,dc=com --enableldaptls --enableldapstarttls --enablesssd --enablesssdauth --enablemkhomedir --updateall

\cp -a /etc/sudo-ldap.conf /etc/sudo-ldap.conf_bak
echo "session    required     pam_mkhomedir.so skel=/etc/skel/ umask=0022" >> /etc/pam.d/sshd
mkdir -p /etc/openldap/ssl
\cp -rvf cacert.pem /etc/openldap/ssl
\cp -rvf ldap.conf /etc/openldap/ldap.conf
\cp -rvf ldap.conf /etc/ssh/ldap.conf
\cp -rvf pam_ldap.conf /etc/pam_ldap.conf
\cp -rvf authconfig /etc/sysconfig/authconfig
\cp -rvf nslcd.conf /etc/nslcd.conf
\cp -rvf nsswitch.conf /etc/nsswitch.conf
\cp -rvf sudo-ldap.conf /etc/sudo-ldap.conf
\cp -rvf sssd.conf /etc/sssd/
chmod 600 /etc/sssd/sssd.conf
service nslcd restart
authconfig --enableldap --enableldapauth --update

sed -i '/^#PubkeyAuthentication yes/a\PubkeyAuthentication yes' /etc/ssh/sshd_config
sed -i '/^#AuthorizedKeysCommand none$/a\AuthorizedKeysCommand /usr/libexec/openssh/ssh-ldap-wrapper' /etc/ssh/sshd_config
sed -i '/^#AuthorizedKeysCommandRunAs nobody$/a\AuthorizedKeysCommandRunAs nobody' /etc/ssh/sshd_config
sed -i '/^#AuthorizedKeysCommandUser nobody$/a\AuthorizedKeysCommandUser nobody' /etc/ssh/sshd_config
sed -i '/^ClientAliveCountMax.*/d' /etc/ssh/sshd_config
echo "ClientAliveCountMax 5" >> /etc/ssh/sshd_config
service sshd restart


