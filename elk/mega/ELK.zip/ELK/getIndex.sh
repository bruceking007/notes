#curl -s -u admin:qPcKy6wVYZu88hZF -XGET http://10.10.0.57:9200/_cat/indices|awk '{print $3}'|grep -E " *-[0-9]{4}\.[0-1][0-9]\.[0-3][0-9]"
#curl -s -u admin:qPcKy6wVYZu88hZF -X GET http://10.10.0.57:9200/.kibana/_search?q=type:index-pattern

#获取现有es里的索引日期
#curl -s -u admin:qPcKy6wVYZu88hZF  http://10.10.0.57:9200/_cat/indices?v |awk -F" " '{print $3}'|grep -vE '^\.|index'|awk -F"-" '{print $NF}'|sort|uniq|sed 's/\./-/g'
#获取现有es里包含nginx的索引日期
curl -s -u admin:qPcKy6wVYZu88hZF  http://10.10.0.57:9200/_cat/indices?v |awk -F" " '{print $3}'|grep -vE '^\.|index'|grep nginx|awk -F"-" '{print $NF}'|sort|uniq|sed 's/\./-/g' > nginxLogDate.txt
#获取现有es里包含jar的索引日期
curl -s -u admin:qPcKy6wVYZu88hZF  http://10.10.0.57:9200/_cat/indices?v |awk -F" " '{print $3}'|grep -vE '^\.|index'|grep jar|awk -F"-" '{print $NF}'|sort|uniq|sed 's/\./-/g' > jarLogDate.txt

