#!/bin/bash
#模版每次都初始化
\cp cfx-dl-vis.ndjson.bak cfx-dl-vis.ndjson

#获取模版中的每个可视化ID前8个字符，每个可视化都有各自的ID
visOricodeArr=($(awk -F ',"id":"' '{print $2}' cfx-dl-vis.ndjson |awk -F - '{print $1}'|grep -v '^$'|xargs))

#获取可视化视图ID数组的长度
arrLength=${#visOricodeArr[*]}
arrTruelen=$(expr $arrLength - 1)

#生产新的随机字符串，8个字符串保护数字和小写字母
visNewcodeArr=($(pwgen -ncCA 8 ${arrLength}|xargs))
echo ${visOricodeArr[@]}
echo ${visNewcodeArr[@]}

#获取模版中的索引模式ID
oriIndexId=$(awk -F 'references' '{print $2}' cfx-dl-vis.ndjson |awk -F '"' '{print $5}'|grep -v ^$|uniq)

#将新生成的字符串替换掉模版中的字符串
fun_sed () {
  for i in `seq 0 $arrTruelen`
    do
        #echo $i
        sed -i "s/${visOricodeArr[$i]}/${visNewcodeArr[$i]}/g" cfx-dl-vis.ndjson
    done
}

fun_sed
read -p "请输入要替换的索引模式ID:" indexPatternId
#sed -i "s/e819be80-22cf-11ee-8261-afbc1c670582/$indexPatternId/g" cfx-dl-vis.ndjson
sed -i "s/$oriIndexId/$indexPatternId/g" cfx-dl-vis.ndjson
read -p "请输入可视化视图标题前缀,如cfox-落地页-:" titleName
sed -i "s/cfox-落地页/$titleName/g" cfx-dl-vis.ndjson
