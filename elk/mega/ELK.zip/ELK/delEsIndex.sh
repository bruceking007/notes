#!/bin/bash
#description: Clear xx days ago!
##ES日志清理##
source /etc/profile
ES_ip=10.10.0.57
USER=admin
PWD=qPcKy6wVYZu88hZF


#定义删除xx天以前的函数
fun_del_log(){
    #check_day=`date -d '-0 days' '+%F'`
    check_day=$(date -d "-${dayago} days" '+%F')
    index_day=$1
    #将日期转换为时间戳
    checkday_timestamp=`date -d "$check_day" +%s`
    echo 'checkday_timestamp' $checkday_timestamp
    indexday_timestamp=`date -d "$index_day" +%s`
    echo 'indexday_timestamp' $indexday_timestamp
    echo "$logtype"
    #当索引的时间戳值小于当前日期xx天前的时间戳时，删除此索引
    if [ ${indexday_timestamp} -lt ${checkday_timestamp} ];then
        #转换日期格式
        format_date=`echo $1 | sed 's/-/\./g'`
        echo $format_date
        curl -s -u ${USER}:${PWD} -XDELETE http://${ES_ip}:9200/*${logtype}*${format_date}
    fi
}

fun_curl () {
    curl -s -u ${USER}:${PWD} http://${ES_ip}:9200/_cat/indices?v |awk -F" " '{print $3}'|grep -vE '^\.|index'|awk -F"-" '{print $NF}'|sort|uniq|sed 's/\./-/g'|while read LINE
    do
        echo "`date +%F_%H-%M-%S` #######"
        fun_del_log $LINE 
   done
}

logTypeArr=(nginx jar)
for logtype in ${logTypeArr[@]}
do
    if [ ${logtype} = "nginx" ];then
        dayago=60
        fun_curl
    elif [ ${logtype} = "jar" ];then
        dayago=6
        fun_curl
    fi
done
