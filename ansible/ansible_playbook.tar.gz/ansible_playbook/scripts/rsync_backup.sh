#!/bin/bash
#1.定义变量
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/root/bin
Host=$(hostname)
IP=$(ifconfig ens33|awk 'NR==2{print $2}')
Date=$(date +%F)
BackupDir=/backup
Dest=${BackupDir}/${Host}_${IP}_${Date}

#2.创建备份目录
mkdir -p $Dest

#3.收集需要备份的文件
#sysconf backup
tar czf ${Dest}/sysconf.tar.gz /etc/fstab /etc/hosts /var/spool/cron/root

#logs backup
tar czf ${Dest}/log.tar.gz /var/log/messages /var/log/secure /var/log/cron

#svrconf backup
tar czf ${Dest}/svrconf.tar.gz /etc/rsyncd.conf

#4.校验
md5sum ${Dest}/* >${Dest}/back_check_$Date

#5.将备份目录推送到rsync服务端
Rsync_IP=172.16.1.12
Rsync_User=rsync_backup
Rsync_Moudle=backup
export Rsync_PASSWORD=1

rsync -avz $Dest $Rsync_User@$Rsync_IP::$Rsync_Moudle

#6.删除7天前的备份目录
find $BackupDir -type d -mtime +7 |xargs rm -rf
