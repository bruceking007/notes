#!/bin/bash
#1.定义变量
Date=$(date +%F)
Path=backup

#2.校验结果
find $Path -type f -name "backup_check_${Date}"|xargs md5sum -c >${Path}/result_$Date

#3.发邮件给管理员
#cat >> /etc/mail.rc << EOF
#set from=751536336@qq.com 
#set smtp=Smtps://smtp.qq.com:465 
#set smtp-auth-user=751536336@qq.com
#set smtp-auth-password=lvkyiherdlmsbeca
#set smtp-auth=login 
#set ssl-verify=ignore
#set nss-config-dir=/etc/ki/nssdb/
#EOF

mail -s "Rsync backup $Date" 751536336@qq.com  < ${Path}/result_$Date

#4.保留最近3天的MD5校验文件
find $Path -type f -name "*.$Date" -mtime 3 |xargs rm -f

#5.保留6个月内的备份内容
find $Path -type d -mtime +180 |xargs rm -rf

