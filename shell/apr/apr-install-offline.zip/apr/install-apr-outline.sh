#/bin/bash
set -x
date=`date +%F-%T`
#mkdir -pv /usr/local/src/apr

#yum -y install gcc gcc-c++ libtool* autoconf automake expat-devel perl perl-devel

function apr () {
	echo -e "\033[32m ================start install apr-1.7.0================ ... \033[0m"
	sleep 2
	cd /usr/local/src/apr
	tar zxvf apr-1.7.0.tar.gz
	sed -i '31279s/$RM/$RM -f/' apr-1.7.0/configure
	grep --color=auto "RM='\$RM -f" apr-1.7.0/configure
	sleep 2
	cd apr-1.7.0
	 ./configure --prefix=/usr/local/apr && make && make install
	echo -e "\033[32m ================finished install apr-1.7.0================ ... \033[0m" >> /usr/local/src/apr/install.log
}

function apr_iconv () {
	echo -e "\033[32m ================start install apr-iconv-1.2.2================ ... \033[0m"
	sleep 2
	cd /usr/local/src/apr
	tar xzvf apr-iconv-1.2.2.tar.gz && cd apr-iconv-1.2.2
	 ./configure --prefix=/usr/local/apr-iconv --with-apr=/usr/local/apr && make && make install
	echo -e "\033[32m ================finished install apr-iconv-1.2.2================ ... \033[0m" >> /usr/local/src/apr/install.log
}

function apr_util () {
	echo -e "\033[32m ================start install apr-util-1.6.1================ ... \033[0m"
	sleep 2
	cd /usr/local/src/apr
	#rpm -ivh expat-devel-2.1.0-12.el7.aarch64.rpm
    yum install -y expat-devel
	tar xzvf apr-util-1.6.1.tar.gz && cd apr-util-1.6.1
	./configure --prefix=/usr/local/apr-util --with-apr=/usr/local/apr --with-apr-iconv=/usr/local/apr-iconv/bin/apriconv && make && make install
	echo -e "\033[32m ================finished install apr-util-1.6.1================ ... \033[0m" >> /usr/local/src/apr/install.log
}

function openssl () {
	echo -e "\033[32m ================start install openssl-1.1.11================ ... \033[0m"
	sleep 2
	cd /usr/local/src/apr
	tar xzvf openssl-1.1.1l.tar.gz && cd openssl-1.1.1l
	./config --prefix=/usr/local/openssl && make -j $(grep processor /proc/cpuinfo | wc -l) && make install
	mv /usr/bin/openssl{,.ori}
	ln -sv /usr/local/openssl/bin/openssl /usr/bin/openssl
	cd /usr/local/src/apr/openssl-1.1.1l  && /bin/cp -av libssl.so.1.1 /usr/lib64/libssl.so.1.1 && /bin/cp -av libcrypto.so.1.1 /usr/lib64/libcrypto.so.1.1
	echo -e "\033[32m ================finished install openssl-1.1.11================ ... \033[0m" >> /usr/local/src/apr/install.log
}

function tomcat_native () {
	echo -e "\033[32m ================start install tomcat-native-1.2.30================ ... \033[0m"
	sleep 2
	jdkDir=`find /usr/java/ -type d -name "jdk1.*"`
	cd /usr/local/src/apr
	tar xzvf tomcat-native-1.2.30-src.tar.gz && cd tomcat-native-1.2.30-src/native/	
	./configure --with-ssl=/usr/local/openssl --with-apr=/usr/local/apr --with-java-home=${jdkDir} && make && make install
	echo -e "\033[32m ================finished install tomcat-native-1.2.30================ ... \033[0m" >> /usr/local/src/apr/install.log
}


function all_install () {
	apr
	apr_iconv
	apr_util
	openssl
	tomcat_native
}


cat << EOF
+--------GPO---------------+
|1、 apr                   |
|2、 apr_iconv             |
|3、 apr_util              |
|4、 openssl               |
|5、 tomcat_native         |
|6、 all_install           |
===========================|
|[Q|q|quit] to quit        |
+--------------------------+
EOF

read -p "----------------------------------------------请选择你要执行的选项编号-------------------------------------------: " choice

case $choice in
    1)
      apr
      ;;
    2)
      apr_iconv 
      ;;
    3)
      apr_util
      ;;
    4)
      openssl
      ;;
    5)
      tomcat_native
      ;;
    6)
      all_install
      ;;	  
    Q|q|quit)
      exit
      ;;
    *)
      echo "程序异常退出,Please: select one number(1|2|3)"
      exit
      ;;
esac



