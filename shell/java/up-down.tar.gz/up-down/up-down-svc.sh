#!/bin/bash
#date 2022-01-10
#des 调用 up-down-jar.sh up-down-java.sh
set -m

red() {
    echo -e "\033[31m $1  \033[0m"
}

blue() {
    echo -e "\033[34m $1  \033[0m"
}

if [ `whoami` != "app" ] ; then
     echo -e "\033[32;5m------------------警告！请使用普通用户app运行此脚本!!!---------------\033[0m"
     exit 1
fi

allarr=$(ls -l /home/java| grep "^d"|awk '{print $NF}'|xargs)
blue "项目目录名称: $allarr"
if [ $# != 2 ];then
    red "请输入两个参数 参数1为/home/java的项目目录名称 参数2为[start|stop|restart|status]"
    blue "示例 sh up-or-down-service.sh jar-demo [start|stop|restart|status]"
    exit 1
fi

set -m
day=$(date +%F)

proDir="$1"
updown="$2"


iftest () {
	if [ -f /home/java/${proDir}/appcode/*.jar ];then
		ifjar
	elif [ -d /home/java/${proDir}/appcode/WEB-INF ];then
		iftom
	else
		red "请输入两个参数 参数1为/home/java的项目目录名称 参数2为[start|stop|restart|status]"
		blue "示例 sh up-or-down-service.sh jar-demo [start|stop|restart|status]"
		exit 1
	fi
}


iftom() {
	binDir="/home/java/$proDir/bin"
	#test ! -f ${binDir}/up-down-java.sh && cp ./son-sh/up-down-java.sh ${binDir}/
	\cp ./son-sh/up-down-java.sh ${binDir}/
	if [ "${updown}" == "start" ];then cd  ${binDir} && ./up-down-java.sh start
	elif [ "${updown}" == "stop" ];then cd  ${binDir} && ./up-down-java.sh stop
	elif [ "${updown}" == "restart" ];then cd  ${binDir} && ./up-down-java.sh restart
	elif [ "${updown}" == "status" ];then cd  ${binDir} && ./up-down-java.sh status
	else
		red "脚本运行错误，请正确执行！"
	fi
}

ifjar() {
    jarDir="/home/java/$proDir/appcode"
    #test ! -f ${binDir}/up-down-jar.sh && cp ./son-sh/up-down-jar.sh ${jarDir}/
    \cp ./son-sh/up-down-jar.sh ${jarDir}/
    if [ "${updown}" == "start" ];then cd  ${jarDir} && ./up-down-jar.sh start
    elif [ "${updown}" == "stop" ];then cd  ${jarDir} && ./up-down-jar.sh stop
    elif [ "${updown}" == "restart" ];then cd  ${jarDir} && ./up-down-jar.sh restart
    elif [ "${updown}" == "status" ];then cd  ${jarDir} && ./up-down-jar.sh status
    else
            red "脚本运行错误，请正确执行！"
    fi
}

#开始运行
iftest
