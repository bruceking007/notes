#!/bin/bash
#date 2022-04-12
#desc up or donw java application
if [ `whoami` != "app" ] ; then
     echo -e "\033[32;5m------------------警告！请使用普通用户app运行此脚本!!!---------------\033[0m"
     exit 1
fi

date=$(date +%F)
export LANG=zh_CN.UTF-8
CATALINA_BASE=$(dirname $(pwd))
APP_NAME=$(pwd|awk -F/ '{print $(NF-1)}')

#使用说明，用来提示输入参数
usage() {
    echo "Usage: sh up-down-java.sh [start|stop|restart|status]"
    exit 1
}

#检查程序是否在运行
is_exist(){
  pid=`ps -ef|grep jdk|grep $APP_NAME|grep -v grep|awk '{print $2}'`
  #如果不存在返回1，存在返回0     
  if [ -z "${pid}" ]; then
   return 1
  else
    return 0
  fi
}

#启动方法
start(){
  is_exist
  if [ $? -eq 0 ]; then
    echo -e "\033[36m ${APP_NAME} 进程还存在，请检查是否已经停掉进程! pid=${pid} \033[0m"
  else
    restart   #函数调用
  fi
}

#停止方法
stop(){
  is_exist
  if [ $? -eq "0" ]; then
    #echo -e "\033[36m ${APP_NAME} 正在关闭...... pid=${pid} \033[0m"
    echo -e "\033[36m[$(date +'%F %T')] >>> Tomcat begin to stop.\033[0m"
    $CATALINA_BASE/bin/shutdown.sh
    pidList=$(ps aux | grep ${APP_NAME} | grep -v grep | awk '{print $2}')
    for pid in $pidList; do
    	kill -9 $pid
    	echo -e "\033[36m[$(date +'%F %T')] >>> Kill the process [$pid] successfully.\033[0m"
    done
    is_exist
    #if [ $? -eq 1 ]; then echo -e "\033[36m ${APP_NAME} 已停! \033[0m";fi
    test $? -eq 1 && echo -e "\033[36m ${APP_NAME} 已停! \033[0m"
  else
    echo -e "\033[31m ${APP_NAME} is not running! \033[0m"
  fi  
}

#输出运行状态
status(){
  is_exist
  if [ $? -eq "0" ]; then
    echo -e "\033[36m ${APP_NAME} is running pid=${pid} \033[0m"
    echo -e "\033[33m 具体如下============= \033[0m"
    ps -ef|grep jdk|grep $APP_NAME|grep -v grep
  else
    echo -e "\033[31m ${APP_NAME} is not running! \033[0m"
  fi
}

#重启
restart(){
	echo -e "\033[36m[$(date +'%F %T')] >>> Tomcat begin to restart.\033[0m"
	$CATALINA_BASE/bin/shutdown.sh
	
	# Kill all remaining processes
	pidList=$(ps aux | grep $CATALINA_BASE | grep -v grep | awk '{print $2}')
	for pid in $pidList; do
	    kill -9 $pid
	    echo -e "\033[36m[$(date +'%F %T')] >>> Kill the process [$pid] successfully.\033[0m"
	done
	
	rm -rf $CATALINA_BASE/work/*
	rm -rf $CATALINA_BASE/temp/*
	
	$CATALINA_BASE/bin/startup.sh
	
	tail -f $CATALINA_BASE/logs/catalina.${date}.out
}

#根据输入参数，选择执行对应方法，不输入则执行使用说明
case "$1" in
  "start")
    start
    ;;
  "stop")
    stop
    ;;
  "status")
    status
    ;;
  "restart")
    restart
    ;;
  *)
    usage
    ;;
esac
