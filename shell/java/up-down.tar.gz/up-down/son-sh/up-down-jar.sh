#!/bin/bash
#date 2022-04-05
#desc up or donw jar application
if [ `whoami` != "app" ] ; then
     echo -e "\033[32;5m------------------警告！请使用普通用户app运行此脚本!!!---------------\033[0m"
     exit 1
fi

APP_NAME=$(ls *.jar)

#使用说明，用来提示输入参数
usage() {
    echo "Usage: sh up-down-jar.sh [start|stop|restart|status]"
    exit 1
}

#检查程序是否在运行
is_exist(){
  pid=`ps -ef|grep java|grep $APP_NAME|grep -v grep|awk '{print $2}'`
  #如果不存在返回1，存在返回0     
  if [ -z "${pid}" ]; then
   return 1
  else
    return 0
  fi
}

#启动方法
start(){
  is_exist
  if [ $? -eq 0 ]; then
    echo -e "\033[36m ${APP_NAME} 进程还存在，请检查是否已经停掉进程! pid=${pid} \033[0m"
  else
    nohup java -jar ${APP_NAME} &
    sleep 1 && tail -f nohup.out
  fi
}

#停止方法
stop(){
  is_exist
  if [ $? -eq "0" ]; then
    echo -e "\033[36m ${APP_NAME} 正在关闭...... pid=${pid} \033[0m" && kill -9 $pid
    is_exist
    #if [ $? -eq 1 ]; then echo -e "\033[36m ${APP_NAME} 已停! \033[0m";fi
    test $? -eq 1 && echo -e "\033[36m ${APP_NAME} 已停! \033[0m"
  else
    echo -e "\033[31m ${APP_NAME} is not running! \033[0m"
  fi  
}

#输出运行状态
status(){
  is_exist
  if [ $? -eq "0" ]; then
    echo -e "\033[36m ${APP_NAME}is running pid=${pid} \033[0m"
    echo -e "\033[33m 具体如下========== \033[0m"
    ps -ef|grep java|grep $APP_NAME|grep -v grep
  else
    echo -e "\033[31m ${APP_NAME} is not running! \033[0m"
  fi
}

#重启
restart(){
  stop
  sleep 2
  start
}

#根据输入参数，选择执行对应方法，不输入则执行使用说明
case "$1" in
  "start")
    start
    ;;
  "stop")
    stop
    ;;
  "status")
    status
    ;;
  "restart")
    restart
    ;;
  *)
    usage
    ;;
esac
