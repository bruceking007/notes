#!/bin/bash
set -x
ip=`ip addr |grep inet |grep -v inet6|grep "10."|awk '{print $2}'|awk -F "/" '{print $1}'|cut -d "." -f1,2,3`
gateway=${ip}.1
sed -i 's/10.32.100.1/'"${gateway}"'/g' ntp_server.conf
cat ntp_server.conf

mkdir -p /usr/local/zabbix/etc/zabbix_agentd.conf.d
mkdir -p /usr/local/zabbix/scripts/ntp
cp -a ./ntp_server.conf  /usr/local/zabbix/etc/zabbix_agentd.conf.d/
cp -a ./compare-ntp-time.py /usr/local/zabbix/scripts/ntp/

ls -l /usr/local/zabbix/etc/zabbix_agentd.conf.d/ntp_server.conf
ls -l /usr/local/zabbix/scripts/ntp/compare-ntp-time.py

python /usr/local/zabbix/scripts/ntp/compare-ntp-time.py ${gateway} 10.32.100.8
service zabbix_agentd restart
