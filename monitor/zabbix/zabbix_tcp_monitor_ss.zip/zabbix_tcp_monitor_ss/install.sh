#!/bin/bash
\cp -arf ./tcp_monitor.conf /usr/local/zabbix/etc/zabbix_agentd.conf.d/
cat /usr/local/zabbix/etc/zabbix_agentd.conf.d/tcp_monitor.conf
mkdir  -p /usr/local/zabbix/scripts/tcp
\cp -arf ./tcp_status.sh /usr/local/zabbix/scripts/tcp/ && chmod +x /usr/local/zabbix/scripts/tcp/tcp_status.sh
ls -l /usr/local/zabbix/scripts/tcp/tcp_status.sh
cat /usr/local/zabbix/scripts/tcp/tcp_status.sh
service zabbix_agentd restart
